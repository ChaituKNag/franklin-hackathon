var http = require("http");

http.createServer(function ( request,response){
	response.writeHead(200,{'Content-Type': 'text/plain'});
	var parsedJson = require('./Questions.json');
	
	//var high = 10;
	//var low = 1;
	//var x = Math.floor(Math.random() * (high - low) + low);
	//console.log("Random variable value is-->"+x);
	 
 var n = 1; 
 var min = 1;
 var max = 10;
 var number = 1;
 var questions;
 var index;
 var question;
 var choice;
 var values = [], i = max;
        while(i >= min) values.push(i--);
        var results = [];
        var maxIndex = max;
        for(i=1; i <= n; i++){
            maxIndex--;
            index = Math.floor(maxIndex * Math.random());
			
              
        }
		response.end("Question"+"\n"+parsedJson.quizdata[index].question+"\n Answers \n "+parsedJson.quizdata[index].choice[0].c+"\n "+parsedJson.quizdata[index].choice[1].c+"\n "+parsedJson.quizdata[index].choice[2].c+"\n "+parsedJson.quizdata[index].choice[3].c);
		
}).listen(8080);